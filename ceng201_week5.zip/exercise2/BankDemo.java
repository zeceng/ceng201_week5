package exercise2;

/**
 * BankDemo.java
 * Lab 5 - Exercise 2 Demo
 * Zeynep Ece ÖZASLAN id:250444039
 */
public class BankDemo {

    public static void main(String[] args) {
        // Create a Bank object
        Bank bank = new Bank();

        // Simulate customer arrivals
        bank.arrive("Ali");
        bank.arrive("Ayse");
        bank.arrive("Mehmet");
        bank.arrive("Zeynep");
        bank.arrive("Can");

        // Display the current bank status
        bank.displayStatus();

        // Complete Teller 2's transaction
        bank.completeTransaction(2);

        // Display the updated bank status
        bank.displayStatus();

        //  Complete Teller 1's transaction
        bank.completeTransaction(1);

        // Display the updated bank status
        bank.displayStatus();
    }
}