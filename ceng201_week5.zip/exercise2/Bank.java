package exercise2;

/**
 * Bank.java
 * Lab 5 - Exercise 2
 * Zeynep Ece ÖZASLAN id:250444039
 */
public class Bank {

    private String[] tellers;
    private Queue waitingQueue;

    public Bank() {
        // Create a String array with 3 elements for tellers
        tellers = new String[3];
        // Initialize all teller positions as null (already null by default in Java)
        for (int i = 0; i < tellers.length; i++) {
            tellers[i] = null;
        }
        //Create a waiting Queue object
        waitingQueue = new Queue();
    }

    public void arrive(String customerName) {
        // Display the customer's arrival message
        System.out.println("Customer " + customerName + " arrived.");

        // Search for an available teller (null value)
        int availableTellerIndex = -1;
        for (int i = 0; i < tellers.length; i++) {
            if (tellers[i] == null) {
                availableTellerIndex = i;
                break;
            }
        }

        //If an available teller is found
        if (availableTellerIndex != -1) {
            tellers[availableTellerIndex] = customerName;
            System.out.println(customerName + " is assigned to Teller " + (availableTellerIndex + 1) + ".");
        } else {
            // Otherwise, add the customer to waitingQueue
            waitingQueue.enqueue(customerName);
            System.out.println("All tellers are busy.");
            System.out.println(customerName + " joins the waiting queue.");
        }
        System.out.println();
    }

    public void completeTransaction(int tellerNumber) {
        //  Check whether tellerNumber is between 1 and 3
        if (tellerNumber < 1 || tellerNumber > 3) {
            System.out.println("Invalid teller number!");
            return;
        }

        int index = tellerNumber - 1;

        //  Check whether the teller is already available
        if (tellers[index] == null) {
            System.out.println("Teller " + tellerNumber + " is already available.");
            return;
        }

        //  Display the completed customer's name
        System.out.println("Teller " + tellerNumber + " completed " + tellers[index] + "'s transaction.");

        // Set the selected teller position to null
        tellers[index] = null;

        // Call assignNextCustomer for that teller
        assignNextCustomer(tellerNumber);
        System.out.println();
    }

    public void assignNextCustomer(int tellerNumber) {
        // Check whether there are customers waiting and assign next customer
        if (!waitingQueue.isEmpty()) {
            String nextCustomer = waitingQueue.dequeue();
            tellers[tellerNumber - 1] = nextCustomer;
            System.out.println(nextCustomer + " is assigned to Teller " + tellerNumber + ".");
        }
    }

    public void displayStatus() {
        System.out.println("\n---------- BANK STATUS ----------");

        // Display the status of all tellers
        for (int i = 0; i < tellers.length; i++) {
            System.out.print("Teller " + (i + 1) + ": ");
            if (tellers[i] == null) {
                System.out.println("Available");
            } else {
                System.out.println(tellers[i]);
            }
        }

        // Display the waiting queue
        System.out.print("Waiting Queue: ");
        waitingQueue.display();

        System.out.println("---------------------------------");
    }
}


