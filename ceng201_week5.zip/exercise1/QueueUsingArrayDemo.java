package exercise1;

/**
 * QueueUsingArrayDemo.java
 * Zeynep Ece ÖZASLAN id:250444039
 * Lab 5 - Exercise 1 Demo
 */
public class QueueUsingArrayDemo {

    public static void main(String[] args) {

        String[] students = {
                "Ali", "Ayse", "Mehmet", "Zeynep", "Ahmet",
                "Elif", "Mustafa", "Fatma", "Can", "Ece",
                "Burak", "Deniz", "Emre", "Selin", "Mert",
                "Ceren", "Kerem", "Dilan", "Onur", "Seda"
        };

        // Create your Queue object with capacity 10
        Queue<String> queue = new Queue<>(10);

        // Insert the first 10 student names into the queue using a for loop
        for (int i = 0; i < 10; i++) {
            queue.enqueue(students[i]);
        }

        // Display the original queue
        System.out.println("Original Queue: " + queue);

        // Display the queue size
        System.out.println("Queue Size: " + queue.size());

        // Display the first student using peek()
        System.out.println("First Student: " + queue.peek());
        System.out.println();

        // Remove three students using dequeue() and display their names
        System.out.println("Removing three students:");
        System.out.println("Removed: " + queue.dequeue());
        System.out.println("Removed: " + queue.dequeue());
        System.out.println("Removed: " + queue.dequeue());
        System.out.println();

        // Display the remaining queue
        System.out.println("Queue After Removal: " + queue);

        // Display the final queue size
        System.out.println("Final Queue Size: " + queue.size());

        /*
         * QUESTION ANSWER:
         * Why does queue.enqueue(students[11]) give an error / problem here?
         * - Because this is a standard linear array-based queue. Even though we dequeued 3 elements
         *   (so front moved forward and there are empty spaces at the beginning), 'rear' has already
         *   reached the maximum capacity index (index 9). The isFull() check evaluates 'count == capacity',
         *   preventing further insertions.
         * - What can you use? We can use a Circular Queue to reuse the freed spaces
         *   at the beginning of the array.
         */
    }
}
