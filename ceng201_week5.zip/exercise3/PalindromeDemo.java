package exercise3;

import java.util.Scanner;

/**
 * PalindromeDemo.java
 * Lab 5 - Exercise 3 Demo
 * Zeynep Ece ÖZASLAN id:250444039
 */
public class PalindromeDemo {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        //  Ask the user to enter a string
        System.out.print("Enter a string: ");
        String text = input.nextLine();

        int length = text.length();

        //  Create a Stack and a Queue with length of input string as capacity
        Stack stack = new Stack(length);
        Queue queue = new Queue(length);

        //  Traverse the string from left to right and insert into both
        for (int i = 0; i < length; i++) {
            char ch = text.charAt(i);
            stack.push(ch);
            queue.enqueue(ch);
        }

        // Assume the string is a palindrome
        boolean isPalindrome = true;

        // Compare characters while the queue is not empty
        while (!queue.isEmpty()) {
            char stackChar = stack.pop();
            char queueChar = queue.dequeue();

            // Compare the two characters
            if (stackChar != queueChar) {
                isPalindrome = false;
                break; // Stop comparing if a mismatch is found
            }
        }

        //  Display whether the string is a palindrome
        if (isPalindrome) {
            System.out.println("\"" + text + "\" is a palindrome.");
        } else {
            System.out.println("\"" + text + "\" is not a palindrome.");
        }

        input.close();
    }
}
