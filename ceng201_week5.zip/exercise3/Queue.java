package exercise3;

/**
 * Queue.java (Circular Character based)
 * Lab 5 - Exercise 3
 * Zeynep Ece ÖZASLAN id:250444039
 */
public class Queue {

    private char[] items;
    private int front;
    private int rear;
    private int count;

    public Queue(int capacity) {
        items = new char[capacity];
        front = 0;
        rear = -1;
        count = 0;
    }

    public void enqueue(char value) {
        //  Check whether the queue is full
        if (isFull()) {
            return;
        }
        // Calculate next rear position using circular indexing and insert
        rear = (rear + 1) % items.length;
        items[rear] = value;
        //  Increase count
        count++;
    }

    public char dequeue() {
        // Check whether the queue is empty
        if (isEmpty()) {
            return '\0';
        }
        //  Store character and move front using circular indexing
        char removedChar = items[front];
        front = (front + 1) % items.length;
        //  Decrease count
        count--;
        //Return the removed character
        return removedChar;
    }

    public char peek() {
        if (isEmpty()) {
            return '\0';
        }
        return items[front];
    }

    public boolean isEmpty() {
        return count == 0;
    }

    public boolean isFull() {
        return count == items.length;
    }

    public int size() {
        return count;
    }
}
