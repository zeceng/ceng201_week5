package exercise3;

/**
 * Stack.java (Character based)
 * Lab 5 - Exercise 3
 *  Zeynep Ece ÖZASLAN id:250444039
 */
public class Stack {

    private char[] items;
    private int top;

    public Stack(int capacity) {
        items = new char[capacity];
        // Initialize top to indicate an empty stack
        top = -1;
    }

    public void push(char value) {
        // Check whether the stack is full
        if (isFull()) {
            return;
        }
        // Increase top and insert the character
        items[++top] = value;
    }

    public char pop() {
        //Check whether the stack is empty
        if (isEmpty()) {
            return '\0';
        }
        // Store character, decrease top, and return it
        return items[top--];
    }

    public char peek() {
        // Check whether the stack is empty
        if (isEmpty()) {
            return '\0';
        }
        // Return the character at the top without removing it
        return items[top];
    }

    public boolean isEmpty() {
        // Return true if the stack is empty
        return top == -1;
    }

    public boolean isFull() {
        // Return true if the stack is full
        return top == items.length - 1;
    }
}
